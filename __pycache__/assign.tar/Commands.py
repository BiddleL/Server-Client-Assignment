from enum import Enum


class Commands(Enum):
    EDG = 1
    UED = 2
    SCS = 3
    DTE = 4
    AED = 5
    OUT = 6
    UVF = 7